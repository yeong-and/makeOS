#define __GNUC__				3
#define __GNUC_MINOR__			2
#define __GNUC_PATCHLEVEL__		0
#define __GXX_ABI_VERSION		102
#define _WIN32					1
#define __WIN32					1
#define __WIN32__				1
#define WIN32					1
#define __MINGW32__				1
#define __MSVCRT__				1
#define WINNT					1
#define _X86_					1
#define __WIN32					1
#define __WINNT					1
#define __NO_INLINE__			1
#define __STDC_HOSTED__			1
#define i386					1
#define __i386					1
#define __i386__				1
#define __tune_i586__			1
#define __tune_pentium__		1
#define __stdcall				__attribute__((__stdcall__))
#define __cdecl					__attribute__((__cdecl__))
#define __fastcall				__attribute__((__fastcall__))
#define _stdcall				__attribute__((__stdcall__))
#define _cdecl					__attribute__((__cdecl__))
#define _fastcall				__attribute__((__fastcall__))
#define __declspec(x)			__attribute__((x))

#define IN_GCC					1
#define HAVE_CONFIG_H			1

#if 0

-lang-c
-Asystem=winnt -Acpu=i386 -Amachine=i386

 J:\MINGW\BIN\..\lib\gcc-lib\mingw32\3.2\cpp0.exe -lang-c -v -iprefix J:\MINGW\B
IN\../lib/gcc-lib/mingw32/3.2/ -D__GNUC__=3 -D__GNUC_MINOR__=2 -D__GNUC_PATCHLEV
EL__=0 -D__GXX_ABI_VERSION=102 -D_WIN32 -D__WIN32 -D__WIN32__ -DWIN32 -D__MINGW3
2__ -D__MSVCRT__ -DWINNT -D_X86_=1 -D_WIN32 -D__WIN32 -D__WIN32__ -D__WIN32__ -D
__MINGW32__ -D__MSVCRT__ -D__WINNT__ -D_X86_=1 -D__WIN32 -D__WINNT -Asystem=winn
t -D__NO_INLINE__ -D__STDC_HOSTED__=1 -Acpu=i386 -Amachine=i386 -Di386 -D__i386
-D__i386__ -D__tune_i586__ -D__tune_pentium__ -D__stdcall=__attribute__((__stdca
ll__)) -D__cdecl=__attribute__((__cdecl__)) -D__fastcall=__attribute__((__fastca
ll__)) -D_stdcall=__attribute__((__stdcall__)) -D_cdecl=__attribute__((__cdecl__
)) -D_fastcall=__attribute__((__fastcall__)) -D__declspec(x)=__attribute__((x))

#endif
