/* !kawai! */
#include "../cp/lang-options.h"
/* #include "f/lang-options.h" */
/* #include "java/lang-options.h" */
/* #include "objc/lang-options.h" */
/* end of !kawai! */
